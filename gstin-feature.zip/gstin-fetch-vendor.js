// GSTIN by PAN Fetch Script for Vendor Master
// This script fetches GSTIN details when PAN is entered

let fetchedGstinsVendor = [];
let selectedGstinVendor = null;

function fetchGSTINsByPANVendor() {
    let pan = document.getElementById("pan_no").value.trim().toUpperCase();
    let gstStatus = document.getElementById("gstStatus");

    if (pan.length !== 10) {
        if (gstStatus) gstStatus.innerHTML = "⚠️ Enter valid 10-digit PAN";
        return;
    }

    if (gstStatus) gstStatus.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Fetching GSTIN details...';

    fetch(window.location.origin + '/vendors/fetch-gstin-by-pan', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ pan_number: pan })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success && data.data.length > 0) {
            fetchedGstinsVendor = data.data;
            displayGSTINOptionsVendor(data.data);
            if (gstStatus) gstStatus.innerHTML = `✅ Found ${data.data.length} GSTIN(s) for this PAN`;
        } else {
            if (gstStatus) gstStatus.innerHTML = data.message || "❌ No GSTIN found for this PAN";
            fetchedGstinsVendor = [];
        }
    })
    .catch(error => {
        console.error('Error:', error);
        if (gstStatus) gstStatus.innerHTML = "⚠️ Unable to fetch GSTIN details. Please enter manually.";
    });
}

function displayGSTINOptionsVendor(gstins) {
    // Remove any existing GSTIN selection div
    const existingDiv = document.querySelector('.gstin-selection-div-vendor');
    if (existingDiv) existingDiv.remove();
    
    let html = '<div class="card mt-3 p-3 bg-light gstin-selection-div-vendor"><h6 class="text-primary">Select GSTIN:</h6>';
    
    gstins.forEach((gstin, index) => {
        html += `
            <div class="form-check mb-2">
                <input class="form-check-input" type="radio" name="selected_gstin_vendor" 
                       id="gstin_vendor_${index}" value="${index}" onchange="fillGSTINDetailsVendor(${index})">
                <label class="form-check-label" for="gstin_vendor_${index}">
                    <strong>${gstin.gstin}</strong> - ${gstin.trade_name || 'N/A'}<br>
                    <small class="text-muted">${gstin.principal_business_address || 'Address not available'}</small>
                </label>
            </div>
        `;
    });
    
    html += '</div>';
    const gstStatus = document.getElementById("gstStatus");
    if (gstStatus) gstStatus.insertAdjacentHTML('afterend', html);
}

function fillGSTINDetailsVendor(index) {
    selectedGstinVendor = fetchedGstinsVendor[index];
    
    // Fill GSTIN
    if (document.getElementById("gstin")) {
        document.getElementById("gstin").value = selectedGstinVendor.gstin || '';
    }
    
    // Fill Business Name
    if (selectedGstinVendor.trade_name) {
        const businessNameInput = document.querySelector('input[name="business_display_name"]');
        if (businessNameInput) {
            businessNameInput.value = selectedGstinVendor.trade_name;
        }
    }
    
    // Fill Address
    if (selectedGstinVendor.principal_business_address) {
        const addressParts = selectedGstinVendor.principal_business_address.split(', ');
        const address1Input = document.querySelector('input[name="address1"]');
        if (address1Input) {
            address1Input.value = addressParts.slice(0, 3).join(', ') || '';
        }
        
        // Extract city/state/pincode if available
        if (selectedGstinVendor.state) {
            const stateSelect = document.querySelector('select[name="state"]');
            if (stateSelect) {
                let option = Array.from(stateSelect.options).find(opt => 
                    opt.value.toLowerCase() === selectedGstinVendor.state.toLowerCase()
                );
                if (!option) {
                    option = new Option(selectedGstinVendor.state, selectedGstinVendor.state, true, true);
                    stateSelect.add(option);
                }
                stateSelect.value = selectedGstinVendor.state;
            }
        }
    }
    
    // Fill Pincode
    if (selectedGstinVendor.pincode) {
        const pincodeInput = document.querySelector('input[name="pincode"]');
        if (pincodeInput) {
            pincodeInput.value = selectedGstinVendor.pincode;
        }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    const panInput = document.getElementById("pan_no");
    if (panInput) {
        panInput.addEventListener("blur", fetchGSTINsByPANVendor);
    }
});
