// GSTIN by PAN Fetch Script for Client Master
// This script fetches GSTIN details when PAN is entered

let fetchedGstins = [];
let selectedGstin = null;

function fetchGSTINsByPAN() {
    let pan = document.getElementById("pan_number").value.trim().toUpperCase();
    let gstStatus = document.getElementById("gstStatus");

    if (pan.length !== 10) {
        gstStatus.innerHTML = "⚠️ Enter valid 10-digit PAN";
        return;
    }

    gstStatus.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Fetching GSTIN details...';

    fetch(window.location.origin + '/clients/fetch-gstin-by-pan', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ pan_number: pan })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success && data.data.length > 0) {
            fetchedGstins = data.data;
            displayGSTINOptions(data.data);
            gstStatus.innerHTML = `✅ Found ${data.data.length} GSTIN(s) for this PAN`;
        } else {
            gstStatus.innerHTML = data.message || "❌ No GSTIN found for this PAN";
            fetchedGstins = [];
        }
    })
    .catch(error => {
        console.error('Error:', error);
        gstStatus.innerHTML = "⚠️ Unable to fetch GSTIN details. Please enter manually.";
    });
}

function displayGSTINOptions(gstins) {
    // Remove any existing GSTIN selection div
    const existingDiv = document.querySelector('.gstin-selection-div');
    if (existingDiv) existingDiv.remove();
    
    let html = '<div class="card mt-3 p-3 bg-light gstin-selection-div"><h6 class="text-primary">Select GSTIN:</h6>';
    
    gstins.forEach((gstin, index) => {
        html += `
            <div class="form-check mb-2">
                <input class="form-check-input" type="radio" name="selected_gstin" 
                       id="gstin_${index}" value="${index}" onchange="fillGSTINDetails(${index})">
                <label class="form-check-label" for="gstin_${index}">
                    <strong>${gstin.gstin}</strong> - ${gstin.trade_name || 'N/A'}<br>
                    <small class="text-muted">${gstin.principal_business_address || 'Address not available'}</small>
                </label>
            </div>
        `;
    });
    
    html += '</div>';
    document.getElementById("gstStatus").insertAdjacentHTML('afterend', html);
}

function fillGSTINDetails(index) {
    selectedGstin = fetchedGstins[index];
    
    // Fill GSTIN
    if (document.getElementById("gstin")) {
        document.getElementById("gstin").value = selectedGstin.gstin || '';
    }
    
    // Fill Business Name
    if (selectedGstin.trade_name && document.getElementById("business_display_name")) {
        document.getElementById("business_display_name").value = selectedGstin.trade_name;
    }
    
    // Fill Address
    if (selectedGstin.principal_business_address) {
        const addressParts = selectedGstin.principal_business_address.split(', ');
        if (document.getElementById("address1")) {
            document.getElementById("address1").value = addressParts.slice(0, 3).join(', ') || '';
        }
        
        // Extract city/state/pincode if available
        if (selectedGstin.state) {
            const stateSelect = document.querySelector('select[name="state"]');
            if (stateSelect) {
                let option = Array.from(stateSelect.options).find(opt => 
                    opt.value.toLowerCase() === selectedGstin.state.toLowerCase()
                );
                if (!option) {
                    option = new Option(selectedGstin.state, selectedGstin.state, true, true);
                    stateSelect.add(option);
                }
                stateSelect.value = selectedGstin.state;
            }
        }
    }
    
    // Fill Pincode
    if (selectedGstin.pincode) {
        const pincodeInput = document.querySelector('input[name="pincode"]');
        if (pincodeInput) {
            pincodeInput.value = selectedGstin.pincode;
        }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    const panInput = document.getElementById("pan_number");
    if (panInput) {
        panInput.addEventListener("blur", fetchGSTINsByPAN);
    }
});
