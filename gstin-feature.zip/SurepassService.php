<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\SystemSetting;

class SurepassService
{
    protected $apiToken;
    protected $baseUrl;
    protected $environment;

    public function __construct()
    {
        $settings = SystemSetting::first();
        $this->apiToken     = $settings->surepass_api_token ?? null;
        $this->environment  = $settings->surepass_api_environment ?? 'production';
        // Determine base URL based on environment (production vs sandbox)
        $this->baseUrl = $this->environment === 'sandbox'
            ? 'https://sandbox-kyc.surepass.io/api/v1'
            : 'https://kyc-api.surepass.io/api/v1';
    }

    /**
     * Fetch GSTIN details by PAN
     * 
     * @param string $pan PAN number
     * @return array
     */
    public function getGstinByPan($pan)
    {
        if (!$this->apiToken) {
            return [
                'success' => false,
                'message' => 'GSTIN API token not configured in system settings'
            ];
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type' => 'application/json',
            ])->post($this->baseUrl . '/gstin/by-pan', [
                'id_number' => strtoupper($pan)
            ]);

            if ($response->successful()) {
                $data = $response->json();
                
                if (isset($data['success']) && $data['success'] === true) {
                    return [
                        'success' => true,
                        'data' => $data['data'] ?? []
                    ];
                }

                return [
                    'success' => false,
                    'message' => $data['message'] ?? 'Failed to fetch GSTIN details'
                ];
            }

            return [
                'success' => false,
                'message' => 'API request failed: ' . $response->status()
            ];

        } catch (\Exception $e) {
            Log::error('GSTIN API Error: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Error connecting to GSTIN API service: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Parse and format GSTIN data from Surepass response
     * 
     * @param array $gstinData
     * @return array
     */
    public function parseGstinData($gstinData)
    {
        $formatted = [];

        if (!isset($gstinData['gstin_list']) || !is_array($gstinData['gstin_list'])) {
            return $formatted;
        }

        foreach ($gstinData['gstin_list'] as $gstin) {
            $formatted[] = [
                'gstin' => $gstin['gstin'] ?? '',
                'trade_name' => $gstin['trade_name'] ?? '',
                'principal_business_address' => $this->formatAddress($gstin['principal_place_address'] ?? []),
                'state' => $gstin['principal_place_address']['state'] ?? '',
                'state_code' => substr($gstin['gstin'] ?? '', 0, 2),
                'pincode' => $gstin['principal_place_address']['pincode'] ?? '',
                'status' => 'Active',
                'is_primary' => false,
            ];
        }

        return $formatted;
    }

    /**
     * Format address from API response
     * 
     * @param array $address
     * @return string
     */
    private function formatAddress($address)
    {
        if (empty($address)) {
            return '';
        }

        $parts = array_filter([
            $address['building_name'] ?? '',
            $address['building_number'] ?? '',
            $address['floor_number'] ?? '',
            $address['street'] ?? '',
            $address['location'] ?? '',
            $address['district'] ?? '',
            $address['state'] ?? '',
            $address['pincode'] ?? '',
        ]);

        return implode(', ', $parts);
    }
}
